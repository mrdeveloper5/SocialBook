// <!-- Owner : Akhlad Kaifi
// Created on 24 July 2023
// personal project
// All Rights Reserverd to Akhladkaifi -->
function settingsMenuToggle(){

}